Conectare cu:
User : oana
Parola : oana

Fisiere:
- in folderul "kanon": programul de kanonimizare
- in "examples" este senderul

Makefiles pentru ambele programe in foldere.

make clean
make

1. Pornire rabbitmq-server (as root):
# rabbitmq-server

2. Rulare program kanon:
./kanon 30000 10 H localhost 5672 amq.direct test > output_1.csv

- primele argumente sunt ce aveam initial in kanon, 30000 numarul de intrari, 10=K, H=hilbert, apoi localhost = unde vrem sa ne conectam pentru a asculta incoming connections pentru rabbitmq, 5672 = portul de rabbitmq, amq.direct = type of exchange, in cazul asta e direct adica le trimite direct la o coada, test = numele cozii.

3. Rulare program de test sending:
./sendstring localhost 5672 amq.direct test "/home/oana/examples/netin1"

- unde netin1 este fisierul cu intrarile noastre pentru a simula primirea datelor prin rabbitmq.

