# -*- coding: utf-8 -*-
"""
Created on Fri Sep 18 00:04:06 2015

@author: elf
"""

import pandas as pd

"""df = pd.read_csv('intervale')

print df.loc[(df['time_start'] < df['time_end'])].index
print df.loc[(df['sip_start'] < df['sip_end'])].index
print df.loc[(df['dip_start'] < df['dip_end'])].index
print df.loc[(df['dport_start'] < df['dport_end'])].index
print df.loc[(df['prot_start'] < df['prot_end'])].index
print df.loc[(df['bytes_start'] < df['bytes_end'])].index
print df.loc[(df['pkts_start'] < df['pkts_end'])].index

#print df.head()
"""

'''
# transform spaces separated file to comma separated file
import csv

with open('netin_data_to_long') as fin, open('netin_data_to_long.csv', 'w') as fout:
    o=csv.writer(fout)
    for line in fin:
        o.writerow(line.split())
'''

#df = pd.read_csv('netin_data_to_long.csv')
'''
for index, row in df.iterrows():
    if (row['dstp'] > 1024 and row['srcp'] <= 1024):
        tmp = row['dstp']
        row['dstp'] = row['srcp']
        row['srcp'] = tmp
    #print index, row['some column']
'''
#df['dstp'][(df['dstp'] > 1024) & (df['srcp'] <= 1024)] = df['srcp']

#df.to_csv('netin_fixed_ports.csv', encoding='utf-8')

df = pd.read_csv('netin1')

#df = df.fillna(0)
#df = df.astype(int)

#print df.size()

df = df[df.dport != 0]

#print df.size()

print df.head()
#df = df.drop(df[(df.dstp > 1024) & (df.dstp != 8083) & (df.dstp != 8080)].index)

#print df.loc[(df['dstp'] > 1024)]
#df.to_csv('netin_fixed_ports.csv', encoding='utf-8')
#df.to_csv('netin_fixed', header=None, sep=' ')
#print df.head()