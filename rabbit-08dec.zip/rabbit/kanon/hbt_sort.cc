/*
 * THIS FILES HANDLES Hilbert SFC
*/

#include <stdlib.h>
#include <assert.h>
#include <stdio.h>

#include "kanon.h"


typedef unsigned long long bitmask_t;
typedef unsigned halfmask_t;

#define adjust_rotation(rotation,nDims,bits)                            \
do {                                                                    \
      /* rotation = (rotation + 1 + ffs(bits)) % nDims; */              \
      bits &= -bits & nd1Ones;                                          \
      while (bits)                                                      \
        bits >>= 1, ++rotation;                                         \
      if ( ++rotation >= nDims )                                        \
        rotation -= nDims;                                              \
} while (0)

#define ones(T,k) ((((T)2) << (k-1)) - 1)
     
#define rotateRight(arg, nRots, nDims)                                  \
((((arg) >> (nRots)) | ((arg) << ((nDims)-(nRots)))) & ones(bitmask_t,nDims))

#define DLOGB_BIT_TRANSPOSE
static bitmask_t bitTranspose(unsigned nDims, unsigned nBits, bitmask_t inCoords)
#if defined(DLOGB_BIT_TRANSPOSE)
{
	unsigned const nDims1 = nDims-1;
	unsigned inB = nBits;
	unsigned utB;
	bitmask_t inFieldEnds = 1;
	bitmask_t inMask = ones(bitmask_t,inB);
	bitmask_t coords = 0;
  	
  	while ((utB=inB/2)) {
		unsigned const shiftAmt = nDims1 * utB;
      	bitmask_t const utFieldEnds = inFieldEnds | (inFieldEnds << (shiftAmt+utB));
      	bitmask_t const utMask = (utFieldEnds << utB) - utFieldEnds;
		bitmask_t utCoords = 0;
		unsigned d;
		if (inB & 1) {
			bitmask_t const inFieldStarts = inFieldEnds << (inB-1);
			unsigned oddShift = 2*shiftAmt;
			for (d = 0; d < nDims; ++d) {
				bitmask_t in = inCoords & inMask;
				inCoords >>= inB;
				coords |= (in & inFieldStarts) <<	oddShift++;
				in &= ~inFieldStarts;
				in = (in | (in << shiftAmt)) & utMask;
				utCoords |= in << (d*utB);
	    	}
		} else {
	  		for (d = 0; d < nDims; ++d) {
				bitmask_t in = inCoords & inMask;
				inCoords >>= inB;
				in = (in | (in << shiftAmt)) & utMask;
				utCoords |= in << (d*utB);
	    	}
		}
		inCoords = utCoords;
		inB = utB;
		inFieldEnds = utFieldEnds;
		inMask = utMask;
    }
	coords |= inCoords;
	return coords;
}
#else
{
	bitmask_t coords = 0;
	unsigned d;
	for (d = 0; d < nDims; ++d) {
		unsigned b;
		bitmask_t in = inCoords & ones(bitmask_t,nBits);
		bitmask_t out = 0;
		inCoords >>= nBits;
		for (b = nBits; b--;) {
			out <<= nDims;
			out |= rdbit(in, b);
		}
		coords |= out << d;
	}
	return coords;
}
#endif

bitmask_t hilbert_c2i(unsigned nDims, unsigned nBits, bitmask_t const coord[]) {
	assert(nDims*nBits<=sizeof(bitmask_t)*8);
	if (nDims>1) {
		unsigned const nDimsBits = nDims*nBits;
		bitmask_t index;
		unsigned d;
		bitmask_t coords = 0;
		for (d = nDims; d--; ) {
			coords <<= nBits;
			coords |= coord[d];
		}
	
		if (nBits > 1) {
			halfmask_t const ndOnes = ones(halfmask_t,nDims);
			halfmask_t const nd1Ones= ndOnes >> 1; /* for adjust_rotation */
			unsigned b = nDimsBits;
			unsigned rotation = 0;
			halfmask_t flipBit = 0;
			bitmask_t const nthbits = ones(bitmask_t,nDimsBits) / ndOnes;
			coords = bitTranspose(nDims, nBits, coords);
			coords ^= coords >> nDims;
			index = 0;
			do {
				halfmask_t bits = (coords >> (b-=nDims)) & ndOnes;
				bits = rotateRight(flipBit ^ bits, rotation, nDims);
				index <<= nDims;
				index |= bits;
				flipBit = (halfmask_t)1 << rotation;
				adjust_rotation(rotation,nDims,bits);
			} while (b);
			index ^= nthbits >> 1;
		} else
			index = coords;
	
		for (d = 1; d < nDimsBits; d *= 2)
			index ^= index >> d;
		return index;
	} else
		return coord[0];
}


double hilbert(double* x,int _dim,bool normalized) {
	unsigned nDims,nBits;
	nDims=_dim;	
	nBits=sizeof(bitmask_t)*8/nDims;		// may be dangerous if nBits*nDims>=32 !

	//printf("%d\n",nDims);	
	// bitmask 8 bytes=64 bits !  (ok for 4D with nBits=16)
	bitmask_t coord[nDims];	// depends on nDims
	bitmask_t cDOM=1;
	cDOM <<= nBits;
	assert(cDOM > 0);
	
	// assumption: x[j] lies in the range [domain_start, domain_finish]
	// we map x[j] to a value in the range [0,cDOM)
	for (int j=0;j<nDims;j++) {
		//printf("j=%d\n", j);
		if (normalized==true){
			coord[j]=(bitmask_t)((x[j])*cDOM);
			assert(x[j]<=1.0);
		}
		else{
			coord[j]=(bitmask_t)(((x[j]-domain_start[j])/(1.0*domain_length[j]))*cDOM);
			//printf("%s x[j]=%lf domain_start[j]=%ld domain_length=%ld\n", __func__, x[j], domain_start[j], domain_length[j]);
			//printf("%s (x[j]-domain_start[j])/(1.0*domain_length[j])=%f\n", __func__, (x[j]-domain_start[j])/(1.0*domain_length[j]));			
			assert((x[j]-domain_start[j])/(1.0*domain_length[j])<=1.0);
			//assert(coord[j]>=0.0);
		}
		if (coord[j]>=cDOM) coord[j]=cDOM-1;
	}
	bitmask_t index=hilbert_c2i(nDims,nBits,coord);
		
	return (double)(index);
}
/*
double hilbert2(double* t,int _dim) {
   int i,n=10;
   unsigned x =(unsigned) t[0],y=(unsigned)t[1];
   unsigned state, s, row;

   state = 0;                            // Initialize.
   s = 0;

   for (i = n - 1; i >= 0; i--) {
      row = 4*state | 2*((x >> i) & 1) | (y >> i) & 1;
      s = (s << 2) | (0x361E9CB4 >> 2*row) & 3;
      state = (0x8FE65831 >> 2*row) & 3;
   }
   return (double)s;
}
*/
int sort_hilbert(const void *d1, const void *d2) {
    DATA *s1=*((DATA **) d1), *s2=*((DATA **) d2);
    double h1=s1->tmp_sort_value;	// much cheaper
    double h2=s2->tmp_sort_value;
    double diff = h1-h2;
    if (diff<0)
        return -1;
    else if (diff>0)
        return 1;
    else
    	return 0;
}

void hbt_sort_array(DATA **objs, int count, bool normalized) {
    	for (int i=0;i<count;i++)
		objs[i]->tmp_sort_value=hilbert(objs[i]->data,DIM-1,normalized);
	qsort(&objs[0],count,sizeof(DATA*),sort_hilbert);
	/*for (int i=0;i<count;i++) {
		printf("id=%d objs[%d]->tmp_sort_value=%lf\n", objs[i]->id, i, objs[i]->tmp_sort_value);
	}*/
//	printf("sorted %d rect.\n", count);
}
