/*
 * THIS FILES HANDLES iDist ordering
*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <assert.h>
#include <string.h>
#include <sys/time.h>

#include <map> 

#include "kanon.h"

using namespace std;
map<int,int> ids;

double _2Dist(DATA **Data, int i, int j){
	double dist = 0.0;
	for (int dim=0;dim<DIM-1;dim++)
		dist += (Data[i]->data[dim]-Data[j]->data[dim])*
				(Data[i]->data[dim]-Data[j]->data[dim]);
	return sqrt(dist);
}

// executes clustering algorithm from Gonzalez (linear in dataset size)
void Gonzalez(DATA ** Data, int DATA_SIZE, DATA ** ref_points){
	int *centers = (int *)malloc((CENTERS+1) * sizeof(int));
	double *dist = (double *)malloc(DATA_SIZE * sizeof(double));
	int *nei = (int *)malloc(DATA_SIZE * sizeof(int));
	
	for (int i = 0; i < DATA_SIZE ; i++)
		dist[i] = 1e30;
	
	//first center
	centers[0] = 0;
	dist[0] = 0;
	nei[0] = 0;
	//ids[0] = 0;
	for (int i = 1; i < DATA_SIZE ; i++){
		dist[i] = _2Dist(Data,0,i);
		nei[i] = 0;
	}
	
	double max;
	int max_i;
	for (int k = 1; k <= CENTERS; k++){
		max = 0;
		for (int i = 1; i < DATA_SIZE ; i++){ // determine farthest
			if (ids.find(i)!=ids.end())
				continue;
			if (dist[i] > max){
				max_i = i;
				max = dist[i];
			}
		}
		//printf("\n%lf",max);		
		//max_i is farthest
		centers[k] = max_i;
		ids[max_i] = max_i;
		dist[max_i] = 0;
		if(k==1){
			for (int i = 0; i < DATA_SIZE ; i++){
				dist[i] = _2Dist(Data,max_i,i);
				nei[i] = max_i;
				}
		}
		else{
		for (int i = 0; i < DATA_SIZE ; i++){ //update dist
			if (_2Dist(Data,max_i,i) < dist[i]){
				nei[i] = max_i;
				dist[i] = _2Dist(Data,max_i,i);
			}
		}
		}
	}
	
	//sort centers
	char s[10];
	double x;
  	for (int i = 0; i < CENTERS; i++)
		for (int j = 0; j < DIM; j++)
			ref_points[i]->data[j] = Data[centers[i+1]]->data[j];
			//ref_points[i]->data[j] = ((int)(Data[centers[i+1]]->data[j]*1000.0))/1000.0;

}


/* sorts the input Data array according to iDist ordering */
void determine_order(DATA **Data,int N,DATA **Sample,int SAMPLE_SIZE){
	//Sample is already normalized, Data is NOT
	DATA ** ref_points = (DATA **)malloc(CENTERS*sizeof(DATA *));
	for (int i=0;i<CENTERS;i++){
		ref_points[i] = (DATA *) malloc (sizeof (DATA));
	}
	
	Gonzalez(Sample,SAMPLE_SIZE,ref_points);	
	hbt_sort_array(ref_points,CENTERS,true);

	double coords[DIM];
	for (int rec=0;rec<N;rec++){
		//compute iDist for each record
		for (int j = 0; j < DIM-1; j++){
			coords[j] = (Data[rec]->data[j]-domain_start[j])/domain_length[j];//normalize data
		}
		
		int mindistnum = -1;
		double mindist = 1e10, dist = 0, temp = 0;

  		for (int i = 0; i < CENTERS; i++) {
      		//calculate the distance to the ith ref point
      		dist = 0;
      		for (int j = 0; j < DIM-1; j++)	{
	  			temp = coords[j] - ref_points[i]->data[j];
	  			dist += temp * temp;
			}
      		//record it if better
      		if (dist < mindist)	{
	  			mindist = dist;
	  			mindistnum = i;
			}
    	}
		assert(mindistnum >= 0);
		/*
		printf("\nbase=%d dist=%lf (%lf %lf)\n",(DIM-1)*mindistnum,sqrt(mindist),
			ref_points[mindistnum]->data[0],ref_points[0]->data[0]);
		*/
		Data[rec]->tmp_sort_value = 1e6*((DIM-1)*mindistnum + sqrt(mindist));
		//scaling is done to avoid value intersections among clusters
		
	}
	
}
