/* Main Part, reads the data and executes the DP algo */

/* TODO: IMPORTANT NOTE
	- Gabi in codul initial avea toate forurile pana la DIM - 1, pentru ca ultima intrare
		din vector nu era un Quasi Identifier, era informatia sensibila care nu intra in calculul costului!

   RUN AS:
   	EXEC_NAME DATASET_SIZE K TYPE(H) < input_file
*/

# include <stdio.h>
# include <stdlib.h>
# include <assert.h>
# include <ctype.h>

# include <sys/types.h>
# include <sys/select.h>
# include <sys/time.h>
# include <sys/types.h>
# include <errno.h>
# include <fcntl.h>
# include <unistd.h>
# include <cstring>

# include <stdint.h>
# include <amqp_tcp_socket.h>
# include <amqp.h>
# include <amqp_framing.h>

# include <assert.h>

# include <pthread.h>

# include "kanon.h"
# include "utils.h"

int K; /* bucket size */
int N; /* dataset size */

int TYPE = -1;
#define HILB 1
#define iDIST 2

#define OPTIMAL_COST_MAX_VALUE 1e30

/* date sip dip dp prot bytes pkts */
/* netin1 - DIM=7 (in kanon.h) date sip dip dp prot bytes pkts */
/* time sip dip dport prot bytes pkts */
unsigned long int domain_length[DIM] = { 130635, 4294967296, 4294967296, 65535, 256, 996585, 10998};

unsigned long int domain_finish[DIM] = { 1442055156, 4294967295, 4294967295, 65535, 255, 996584, 10998};
unsigned long int domain_start[DIM] =  { 1441924521, 0, 0,  0,    0,   0, 1};

bool isNumeric[DIM]={true, true, true, true, true, true, true};
bool hasList[DIM]={false, false, false, true, true, false, false};

const char* hier_files[DIM] =
	{
		"",
		"",
		"",
		"",
		"",
		"",
		""
	};

Hentry Hierarchy[DIM];

struct timeval begin, stop;

/* Here is where we will store the data that we will read from the file or the data that we will receive from the network (still reading a file in this version, even from the network) */
DATA **Data;
DATA **Sample;

typedef struct bucket
{
	list < int > members;
	double cost;
	double partial_cost[DIM];
	double start[DIM];
	double end[DIM];
	//vector < list <double> > list_elems;
	//list < double > port_range;
	//list < double > prot_range;
	list < double > list_elems[DIM];	
} bucket;

/*
cost
min,max,

*/

/* a list of pointers to buckets for ... */
list < bucket * > Bag;


/* the dynamic programming structures, we have a matrix of DP as a vector and each entry has a DATA array (what for...?) and a list of buckets that are contributing to that entry */
typedef struct DP_Entry
{
	int pred;		//index of pred with same SA
	int succ;		//index of pred with same SA
	int sa_val;
	double coord;		//my coord i.e. Hilb val
	bool first;
	bool assigned;
	list < bucket > buckets;
	DATA *data;
} DP_Entry;

DP_Entry *Table;

/* pthreads declarations go here */
#define NUM_THREADS 2
#define COUNT_LIMIT 34000 /* TODO: change this for multiple values bla bla */

int outside_count = 0;
int thread_ids[2] = {0,1};
pthread_mutex_t count_mutex;
pthread_cond_t count_threshold_cv;

/* FILE NAME HERE TODO: change this */
const char *inOutFile = "inOutFile";

/*
   Other function declarations go here
*/

double get_MBR(bucket *b, double start[], double end[]);


/* Rabbit-MQ integration goes here - we need a listener for the queue
   all the values that are nedded for starting a new queue
 */
char const *hostname;
int port, status;
char const *exchange;
char const *bindingkey;

void *handle_session(void *) {

  //printf("in handle_session\n");

  amqp_socket_t *socket = NULL;
  amqp_connection_state_t conn;

  conn = amqp_new_connection();

  socket = amqp_tcp_socket_new(conn);
  if (!socket) {
	die("creating TCP socket");
  }
  //printf("created TCP socket\n");

  status = amqp_socket_open(socket, hostname, port);
  //printf("status = %d\n", status);
  if (status) {
	die("opening TCP socket");
  }
  //printf("opened TCP socket\n");

  amqp_bytes_t queuename;

  die_on_amqp_error(amqp_login(conn, "/", 0, 131072, 0,    AMQP_SASL_METHOD_PLAIN, "guest", "guest"),
                    "Logging in");
  amqp_channel_open(conn, 1);
  die_on_amqp_error(amqp_get_rpc_reply(conn), "Opening channel");

  {
    amqp_queue_declare_ok_t *r = amqp_queue_declare(conn, 1, amqp_empty_bytes, 0, 0, 0, 1,
                                 amqp_empty_table);
    die_on_amqp_error(amqp_get_rpc_reply(conn), "Declaring queue");
    queuename = amqp_bytes_malloc_dup(r->queue);
    if (queuename.bytes == NULL) {
      fprintf(stderr, "Out of memory while copying queue name");
      exit(1);
    }
  }

  amqp_queue_bind(conn, 1, queuename, amqp_cstring_bytes(exchange), amqp_cstring_bytes(bindingkey),
                  amqp_empty_table);
  die_on_amqp_error(amqp_get_rpc_reply(conn), "Binding queue");

  amqp_basic_consume(conn, 1, queuename, amqp_empty_bytes, 0, 1, 0, amqp_empty_table);
  die_on_amqp_error(amqp_get_rpc_reply(conn), "Consuming");

  FILE *fp;
  //char fileName[256];
  //const char* baseFile = "input_";

  {
    setbuf(stdout, NULL);
    int count = 0;
    //int fileEnd = 1;
    //snprintf(fileName, sizeof(fileName), "%s%d", baseFile, fileEnd);
    //printf("FILENAME %s\n", fileName);
    //fp = fopen(fileName, "wt");
    fp = fopen(inOutFile, "wt");
    //printf("opened file %s\n", inOutFile);

    while (1) {
      amqp_rpc_reply_t res;
      amqp_envelope_t envelope;

      amqp_maybe_release_buffers(conn);

      res = amqp_consume_message(conn, &envelope, NULL, 0);

      if (AMQP_RESPONSE_NORMAL != res.reply_type) {
        break;
      }


      //amqp_dump(envelope.message.body.bytes, envelope.message.body.len); 
      
      /*if (count > 9999) {
        fclose(fp);
        fileEnd++;
        snprintf(fileName, sizeof(fileName), "%s%d", baseFile, fileEnd);
        fp = fopen(fileName, "wt");
        count = 0;
      } else {*/
        int len = envelope.message.body.len;
        char *chs = (char *)calloc(len, sizeof(char *));
        strncpy(chs, (char *)envelope.message.body.bytes, len);
	// pthread stuff here	
	pthread_mutex_lock(&count_mutex);
	//printf("mutex lock in handle_session\n");
        fprintf(fp, "%s", chs);
	fflush(stdout);
        outside_count++;
	/*Check the value of count and signal waiting thread when condition is reached.  Note that this occurs while mutex is locked. 
        */
	//printf("outside_count = %d\n", outside_count);
    	if (outside_count == COUNT_LIMIT) {
      		pthread_cond_signal(&count_threshold_cv);
      	}
	pthread_mutex_unlock(&count_mutex);
      //}

      amqp_destroy_envelope(&envelope);

    }
    fclose(fp);
  }

  die_on_amqp_error(amqp_channel_close(conn, 1, AMQP_REPLY_SUCCESS), "Closing channel");
  die_on_amqp_error(amqp_connection_close(conn, AMQP_REPLY_SUCCESS), "Closing connection");
  die_on_error(amqp_destroy_connection(conn), "Ending connection");

  pthread_exit(NULL);
}


/* initialize attribute hierarchies;
   hierarchies are slightly different from your Mondrian IMPL
   which I have used; the corresponding files are included
*/
void read_hierarchies(){
	
	for (int dim=0;dim<DIM-1;dim++)
	if(isNumeric[dim]==false){
		int tmp;
		FILE *fp = fopen(hier_files[dim],"r");
		assert(fp != NULL);
		fscanf(fp,"%d",&tmp);//# levels
		Hierarchy[dim].max_level = tmp-1;
		for (int level=0;level<=Hierarchy[dim].max_level;level++){
			fscanf(fp,"%d",&tmp);//# entries in this level
			IntervalEntry ie;
			for (int i=0;i<tmp;i++){
				fscanf(fp,"%d",&(ie.start));
				fscanf(fp,"%d",&(ie.finish));
				ie.count = ie.finish - ie.start + 1;
				Hierarchy[dim].levels[level].push_back(ie);
				if (level == Hierarchy[dim].max_level){
					printf("DIM is %d\n", i);
					assert(tmp == 1);
					assert(ie.start == 1);
					for (int elem = ie.start; elem <= ie.finish; elem++)
						Hierarchy[dim].unique.insert(elem);
					assert(Hierarchy[dim].unique.size()==(ie.finish-ie.start+1));
				}
			}
		}
	}	
}

double get_MBR(bucket *b, double start[], double end[]);


/* as QID dimensionality changes, this routine must be updated !!! */
void
read_table ()
{
	FILE *fo;
	fo = fopen(inOutFile, "rt");
	//printf("opened file %s\n", inOutFile);
	/* right now we read no hierachies TODO uncomment this */
	//read_hierarchies();
	/*for (int i = 0; i < DIM - 1; i++) {
		printf("============HIERARCHY %d===========\n", i);
		for (int j = 0; j < Hierarchy[i].max_level; j++) {
			for(int k = 0; k < Hierarchy[i].levels[j].size(); k++) {
				printf("Level %d, value[%d]=%d\n", j, k, Hierarchy[i].levels[j].at(k));
			}
		}
		printf("\n");
	}*/

	srand48(324234);
	
	int i, j;

	/*printf("Print the domain lenght\n");
	for (i = 0; i < DIM; i++) {
		printf("attri %i = %ld\n", i, domain_length[i]);
	}

	printf("Print the domain start\n");
	for (i = 0; i < DIM; i++) {
		printf("attri %i = %ld\n", i, domain_start[i]);
	}

	printf("Print the domain finish\n");
	for (i = 0; i < DIM; i++) {
		printf("attri %i = %ld\n", i, domain_finish[i]);
	}*/

	Data = (DATA **) malloc (N * sizeof (DATA *));
	for (i = 0; i < N; i++)
	{
		Data[i] = (DATA *) malloc (sizeof (DATA));
		
		//printf("Reading the id...\n");
		fscanf (fo, "%d", &(Data[i]->id));//key
		//printf("i=%d\tData[i]->id=%d\n", i,Data[i]->id);
		assert(i==Data[i]->id);
		//fprintf(stderr,"%d", Data[i]->id);

		for (j = 0; j < DIM; j++)
		{
			//printf("==========J=%d==========\n", j);
			fscanf (fo, "%lf", &(Data[i]->data[j]));
			//printf("Data[i]->data[j]=%f\n", Data[i]->data[j]);
			//printf("domain_start[j]=%lu\tdomain_finish[j]=%lu\n",domain_start[j], domain_finish[j]);

			assert(((double)(Data[i]->data[j])<=domain_finish[j]) && 
						((double)(Data[i]->data[j])>=domain_start[j]));

		}

		/*for (j = 0; j < DIM; j++) {
			printf("i=%d\tData[i]->data[j]=%lf\n", i, Data[i]->data[j]);
		}*/	
	}

	fclose(fo);

	Table = new DP_Entry[N];

	//read records
	double coord;
	for (int i = 0; i < N; i++)
	{
		coord = (Data[i]->tmp_sort_value);
		Table[i].data = Data[i];
		Table[i].coord = coord;
		Table[i].assigned = false;
	}
	
	hbt_sort_array(Data,N,false);

}

/*
    Get the Minimum Bounding Rectangle for the current bucket
*/

double
get_MBR (bucket * crt_bkt, double start[], double end[])
{
	DATA min, max;

	/* initialize the min and max DATA arrays */
	for (int i = 0; i < DIM; i++) {
		min.data[i] = 9007199254740991;//surely larger than domain size
		max.data[i] = -1;
	}

	/* find the minimum and maximum value for each dimension in the current bucket */
	for (list < int >::iterator it2 = crt_bkt->members.begin ();
	     it2 != crt_bkt->members.end (); it2++) {

		DATA *crt_data = Table[(*it2)].data;

		for (int i = 0; i < DIM; i++) {
			if (crt_data->data[i] < min.data[i])
				min.data[i] = crt_data->data[i];
			if (crt_data->data[i] > max.data[i])
				max.data[i] = crt_data->data[i];
		}

		/*if (*it2 == 1) {
			printf("AICI\n");
			for (int i = 0; i < DIM; i++)
			{
				printf("crt_data->data[i]=%lf, min.data[i]=%lf, max.data[i]=%lf\n", crt_data->data[i],min.data[i], max.data[i]);
			}
		}*/
	}

	for (list < int >::iterator it2 = crt_bkt->members.begin ();
	     it2 != crt_bkt->members.end (); it2++) {

		DATA *crt_data = Table[(*it2)].data;

		for (int i = 0; i < DIM; i++) {
			if (hasList[i] == true) {
				crt_bkt->list_elems[i].push_back(crt_data->data[i]);
			}
		}
	}

	/*printf("PRINTING IN calculate MBR\n");
	for (int i = 0; i < DIM; i++) {
		if (hasList[i] == true) {
			list<double>::iterator iter;
			for (iter = crt_bkt->list_elems[i].begin(); iter != crt_bkt->list_elems[i].end(); iter++)
				printf("%lf \n", (*iter)); 
		}
	}*/

	//exit(0);

	/*for (int i = 0; i < DIM; i++) {
		printf("i=%d min.data[i]=%lf max.data[i]=%lf\n", i, min.data[i], max.data[i]);
	}*/
	
	double size = 0.0;
	for (int i = 0; i < DIM; i++)
	{
		if (isNumeric[i] == false) {
			int minval = (int) min.data[i],maxval =(int) max.data[i];
			if (minval == maxval) {
				size += 0.0;
			} else {
				bool flag = true;
				for (int level=0; flag==true ;level++) {
					for (vector <IntervalEntry>::iterator it = 
							Hierarchy[i].levels[level].begin();
							it != Hierarchy[i].levels[level].end();
							it++) {

						if ( (minval >= (*it).start) && (maxval <= (*it).finish) ) {
							double incr = 1.0*((*it).count)/Hierarchy[i].unique.size();
							size += incr;
							assert((incr >= 0.0)&&(incr <= 1.0));
							flag = false;
							break;
						}
					}
				}
				assert(flag==false);
			}
		} else {
			double incr = (max.data[i] - min.data[i]) / domain_length[i];
			size += incr;
			assert((incr >= 0.0)&&(incr <= 1.0));
		}
	}

	//printf ("\nCost = %lf", size);
	/* get the dimensions of the data - minimum and maximum values for each dimension */
	for (int i = 0; i < DIM; i++) {
		start[i] = min.data[i];
		end[i] = max.data[i];
	}

	return size * crt_bkt->members.size();
}

/* to speed things up, compute current MBR based on
   the MBR of the previous sequence (which is a prefix of current one)
*/
int print_count=0;
double
get_incr_MBR (bucket * crt_bkt, int new_member)
{
	/* initialize the current bucket with the first member, initially partial_cost is 0.0
	*/
	if (new_member == -1) {
		int first = crt_bkt->members.front();
		for (int i = 0; i < DIM; i++) {
			crt_bkt->start[i] = crt_bkt->end[i] = Table[first].data->data[i];
			crt_bkt->partial_cost[i] = 0.0;

			/*if (hasList[i] == true) {
				printf("hasList[%d]==true so we add %lf...\n", i, Table[first].data->data[i]);
				crt_bkt->list_elems[i].push_back(Table[first].data->data[i]);
				printf("added...\n");
			}*/
		}
		crt_bkt -> cost = 0;
		return 0.0;

		list < double >::iterator iter = crt_bkt->list_elems[3].begin();
		while (iter != crt_bkt->list_elems[3].end()) {
      			printf("elem %lf ", *iter);
      			iter++;
    		}
		//exit(0);
	}
	print_count++;
	if (print_count % 1000 == 0)
		fprintf(stderr, "=");
	//printf("Are we here yet?!?\n");

	DATA * crt_rec = Table[new_member].data;
	
	/* check if the current member changes the limits for the current bucket, if so then change flags
	*/
	bool flag_part[DIM];
	bool flag_chg = false;
	for (int i = 0; i < DIM; i++)
	{
		if (crt_rec->data[i] < crt_bkt->start[i]){
			crt_bkt->start[i] = crt_rec->data[i];
			flag_chg = true;
			flag_part[i] = true;
		}

		if (crt_rec->data[i] > crt_bkt->end[i]){
			crt_bkt->end[i] = crt_rec->data[i];
			flag_chg = true;
			flag_part[i] = true;
		}

		if (hasList[i] == true) {
				//printf("hasList[%d]==true so we add %lf...\n", i, crt_rec->data[i]);
				crt_bkt->list_elems[i].push_back(crt_rec->data[i]);
				//printf("added...\n");
		}		
	}

	/*for (int i = 0; i < DIM; i++) {
		if (hasList[i] == true) {
			list<double>::iterator iter;
			for (iter = crt_bkt->list_elems[i].begin(); iter != crt_bkt->list_elems[i].end(); iter++)
				printf("%lf \n", (*iter)); 
		}
	}
	exit(0);*/	

	/* if the current member doesn't change the limits of the bucket, then return the cost as it is,
	   no need for further computation for the cost now 
	*/
	if (flag_chg == false)
		return crt_bkt->cost*crt_bkt->members.size();

	/* the current member changed one of the limits of the bucket for one dimension
	*/
	double size = 0.0;
	for (int i = 0; i < DIM; i++) {
		/* nothing changed for this dimension, 
		   so we can skip calculating the cost for it
		*/
		if (flag_part[i] == false) continue;

		/* calculate the cost
		*/
		if (isNumeric[i] == false) {
			int minval = (int) crt_bkt->start[i],maxval = (int) crt_bkt->end[i];

			if (minval == maxval) {
				size += 0.0;
			} else {
				bool flag = true;
				for (int level=0; flag == true ;level++) {
					for (vector <IntervalEntry>::iterator it = 
							Hierarchy[i].levels[level].begin();
							it != Hierarchy[i].levels[level].end();
							it++) {

						assert(level <= Hierarchy[i].max_level);
						if ( (minval >= (*it).start) && (maxval <= (*it).finish)) {
							double incr = 1.0*((*it).count)/Hierarchy[i].unique.size();
							size += incr - crt_bkt->partial_cost[i];
							crt_bkt->partial_cost[i] = incr;
							assert((incr >= 0.0)&&(incr <= 1.0));
							flag = false;
							break;
						}
					}
				}
				assert(flag==false);
			}
		} else {
			/* if our domain is numeric, then we can calculate the cost as follows:
				- difference between end and start of the bucket interval, over the domain length
				- this is a partial cost (the difference) - as in the cost of the bucket until this member including; 
				- update the partial cost field in the current bucket
				- partial cost used later for calculating the total cost
			*/
			double incr = 1.0*(crt_bkt->end[i] - crt_bkt->start[i]) / 	domain_length[i];
			size += incr - crt_bkt->partial_cost[i];
			//printf("index=%d incr=%f size=%f\n", i, incr, size);
			crt_bkt->partial_cost[i] = incr;
			assert((incr >= 0.0)&&(incr <= 1.0));
		}
	}

	/*printf ("new_member=%d Cost = %lf\t", new_member, size);
	for (int i = 0; i < DIM; i++) {
		printf("%lf, %lf,", crt_bkt->start[i], crt_bkt->end[i]);
	}
	printf("\n");*/

	crt_bkt->cost += size ;
	return (crt_bkt->cost * crt_bkt->members.size());
}

/***********1D KANON**************/

/* used to tabulate "immediate" cost in DP formulation
*/
double **COST;


double cost(int start, int end) {
	if (start == end)
		return 0.0;

	//assert(start < end);

	if (COST[start][end] >= 0.0)
		return COST[start][end];
	assert(0);
}


void OneD_KANON(int DATA_SIZE, int KK) {

	/* S stores the optimal cost at i, SI the corresponding index */
	double *S = (double *) malloc(DATA_SIZE * sizeof(double));
	int *SI = (int *) malloc(DATA_SIZE * sizeof(int));
	
	int buckets = 0;
	
	COST = (double **) malloc(DATA_SIZE * sizeof(double *));
   	assert (S != NULL);
	assert (COST != NULL);
	
	/* initialize the COST matrix COST [ DATA_SIZE x (2*KK - 1) ] with -1.
	*/
    	for (int i = 0; i < DATA_SIZE; i++) {
		COST[i] = (double *) malloc ((2*KK-1) * sizeof(double));
		for (int j = 0; j < (2*KK-1); j++)
			COST[i][j] = -1.0;
	}

	/* PRECOMP COST 1D DIST
		- for each member in the DATA compute cost for each of the (i+1, i + 2*KK - 1) next members, adding them all to the same bucket
	*/
	fprintf(stderr, "Adding flows to buckets...\n");
	for (int i = 0; i < DATA_SIZE; i++){
		//printf("\n\n=====i=%d=====\n\n", i);

		bucket *b = new bucket;
		b->members.push_back(i);
		COST[i][0] = get_incr_MBR(b,-1);//initialize
		assert(COST[i][0]==0.0);
		//COST[i][0]=Table[i].coord - Table[0].coord;


		for (int j = i+1; (j < DATA_SIZE) && (j<i+2*KK-1); j++) {
			b->members.push_back(j);
			
			// only one of the two following lines at a time;
			// second is for "Fast" version
			COST[i][j-i] = get_incr_MBR(b,j);
			//COST[i][j-i] = Table[j].coord - Table[i].coord;
			
		}
		b->members.clear();
		delete b;
	}

	/* print the precomputed cost
	printf("\n\n COST for kk=%d\n\n", KK);
	for (int i = 0; i < DATA_SIZE; i++){
		for (int j = 0; j < (2*KK-1); j++)
			printf("%lf,",COST[i][j]);
		printf("\n");
	}
	printf("\n\n");*/


	/* initialize the optimal cost and the corresponding index
	*/
    	for (int i = KK-1; i < 2*KK -1; i++){
		S[i] = cost(0,i);
		SI[i] = 0;
	}


	int min_j;
	for (int i = 2*KK-1; i < DATA_SIZE; i++) {

		S[i] = OPTIMAL_COST_MAX_VALUE;

		for (int j = (((i - 2*KK + 1) > KK-1) ? (i - 2*KK + 1) : KK-1); j < i-KK+1; j++) {
			assert(j>=(KK-1));

			if ( (S[i] > S[j]+ cost(j+1,i-j-1)) ) {
				S[i] = S[j] + cost(j+1,i-j-1);
				SI[i] = j;
			}
		}
	}
	
	/* TODO: print before this what the contents of S and SI arrays are
	   "OUTPUT" solution
	   - while the corresponding index of the optimal cost is bigger than KK-1
		- walk through the DATA array (in reverse, from end to start) and add to the current bucket all
		  those indexes that are bigger than the corresponding index for the optimal cost
		- calculate the Minimum Bounding Rectangle for this bucket
		- add the bucket to the bag
	*/

	int j = DATA_SIZE-1;
	while (SI[j] >= (KK-1)) {

		bucket *b = new bucket();
		for (int crt = j; crt > SI[j]; crt--) {
			b->members.push_back(crt);
		}

		b->cost = get_MBR(b, b->start, b->end);

		//printf("DATA_SIZE=%d j=%d SI[j]=%d KK=%d b->members.size=%ld\n", DATA_SIZE,j, SI[j], KK,b->members.size());

		Bag.push_front(b);
		j = SI[j];
	}
	
	/* first bucket cause we only walked until KK-1 maximum in the DATA array
	*/
	bucket *b = new bucket();
	for (int crt = j; crt >= 0; crt--)
		b->members.push_back(crt);
	b->cost = get_MBR(b, b->start, b->end);
	Bag.push_front(b);

	/* THE ACTUAL PRINTING OF THE CONTENTS OF THE BUCKETS or of the VALUES
	*/
	int index=0;
	// netin3 printf("Bucket,cost,sip_start,sip_end,dip_start,dip_end,dport_start,dport_end,bytes_start,bytes_end,pkts_start,pkts_end\n");

	// netin2 printf("Bucket,cost,sip_start,sip_end,dip_start,dip_end,dport_start,dport_end,prot_start,prot_end,bytes_start,bytes_end,pkts_start,pkts_end\n");

	// netin1
	/*printf("Bucket,cost,time_start,time_end,sip_start,sip_end,dip_start,dip_end,dport_start,dport_end,prot_start,prot_end,bytes_start,bytes_end,pkts_start,pkts_end\n");
	for (list < bucket* >::iterator it = Bag.begin(); it != Bag.end(); it++, index++)
	{
		printf("%d,%lf,", index, (*it)->cost);		
		
		for (int i = 0; i < DIM; i++) {
			if (i == DIM-1) 
				printf("%lf, %lf", (*it)->start[i], (*it)->end[i]);
			else
				printf("%lf, %lf,", (*it)->start[i], (*it)->end[i]); 
		}
		printf("\n");
	}*/

		printf("Bucket,time_start,time_end,sip_start,sip_end,dip_start,dip_end,dport_range,prot_range,bytes_start,bytes_end,pkts_start,pkts_end\n");
	for (list < bucket* >::iterator it = Bag.begin(); it != Bag.end(); it++, index++)
	{
		printf("%d,", index);		
		
		for (int i = 0; i < DIM; i++) {
			if (i == DIM-1) {
				if (hasList[i] == true) {
					(*it)->list_elems[i].sort();
					(*it)->list_elems[i].unique();
					list<double>::iterator iter;
					printf("{");
					for( iter = (*it)->list_elems[i].begin(); iter != (*it)->list_elems[i].end(); ++iter) {
						printf("%lf ", *iter);
					}
					printf("}");
				
				//printf("list size = %ld ", (*it)->list_elems[i].size());

				/*list<double>::iterator iter;
				for (iter = (*it)->list_elems[i].begin(); iter != (*it)->list_elems[i].end(); iter++)
					printf("%lf \n", (*iter));*/
				} else
					printf("%lf, %lf", (*it)->start[i], (*it)->end[i]);
			} else {
				if (hasList[i] == true) {
					(*it)->list_elems[i].sort();
					(*it)->list_elems[i].unique();
					list<double>::iterator iter;
					printf("{");
					for( iter = (*it)->list_elems[i].begin(); iter != (*it)->list_elems[i].end(); ++iter) {
						printf("%lf ", *iter);
					}
					printf("},");
				} else
					printf("%lf, %lf,", (*it)->start[i], (*it)->end[i]);
			}
//			if (hasList[i] == true) {
				/*list<double>::iterator iter;
				printf("{");
				for( iter = (*it)->list_elems[i].begin(); iter != (*it)->list_elems[i].end(); ++iter) {
					printf("%lf ", *iter);
				}
				printf("}");*/
			/*	(*it)->list_elems[i].sort();
				(*it)->list_elems[i].unique();
				printf("list size = %ld ", (*it)->list_elems[i].size());
*/
				/*list<double>::iterator iter;
				for (iter = (*it)->list_elems[i].begin(); iter != (*it)->list_elems[i].end(); iter++)
					printf("%lf \n", (*iter));*/
			//}
		}
		printf("\n");
	}


	/* print the contents of each bucket
	int index = 0;
	for (list < bucket* >::iterator it = Bag.begin(); it != Bag.end(); it++, index++)
	{
		printf("\nBucket %d, cost=%lf, it->members.size=%ld, members:\n", index, (*it)->cost,(*it)->members.size());		
		
		for (list < int >::iterator it2 = (*it)->members.begin (); it2 != (*it)->members.end (); it2++)
		{
			printf("%d\t", Data[*it2]->id);
		}
		
	}*/

}
/***********END 1D KANON**************/


void *kanon(void *t) {

	//printf("in kanon\n");

	/* Lock mutex and wait for signal.
	*/

	gettimeofday(&begin, NULL);
	
	pthread_mutex_lock(&count_mutex);
	//printf("mutex_lock in kanon\n");
 	while (outside_count<COUNT_LIMIT) {
		//printf("Got here, so outside_count = %d\n", outside_count);
    		pthread_cond_wait(&count_threshold_cv, &count_mutex);
	}
	read_table ();
	/***** START *****/
	OneD_KANON(N,K);
	/**********FINISH*****************/
	pthread_mutex_unlock(&count_mutex);
	gettimeofday(&stop, NULL);
	
	double avg_cost = 0;
	double DM = 0.0;
	int count=0;

	for (list < bucket * >::iterator it = Bag.begin ();
	     it != Bag.end (); it++)
	{
		(*it)->cost = get_MBR(*it, (*it)->start, (*it)->end);
		avg_cost += (*it)->cost;
		
		//for discernability metric
		DM += (*it)->members.size() * (*it)->members.size();
		count++;

	}

	/*for (int i = 0; i < N; i++)
	{
		printf("Table[%d]->coord=%lf\n", i, Table[i].coord);
	}*/

	// TODO:print the start and end values for the interval
	/*int index = 0;
	for (list < bucket* >::iterator it = Bag.begin(); it != Bag.end(); it++, index++)
	{
		printf("\nBucket %d, cost=%lf:\n", index, (*it)->cost);
		for (int i = 0; i < DIM; i++) {
			 printf("it->start=%lf, it->end=%lf\n", (*it)->start[i], (*it)->end[i]);
		}		
	}*/

	fprintf (stderr, "\n%d %lf %lf \n", K, avg_cost/N/(DIM-1),
		(stop.tv_sec - begin.tv_sec)*1.0 + 
		(stop.tv_usec - begin.tv_usec)/1000000.0
	);

	//pthread_exit(NULL);
}

int
main (int argn, char **args)
{
	N = atoi (args[1]);	// nr records
	K = atoi (args[2]);	// K-value
	
	if (args[3][0]=='H')
		TYPE = HILB;
	else
		TYPE = iDIST;

	/* RABBITMQ setting up */
	hostname = args[4];
  	port = atoi(args[5]);
  	exchange = args[6];
  	bindingkey = args[7];
	
	//fprintf(stderr, "hostname = %s port = %d exchange = %s bindingkey = %s\n", hostname, port, exchange, bindingkey);

	/* pthread stuff goes here */
	int i, rc;
  	long t1=1, t2=2;
  	pthread_t threads[2];
  	pthread_attr_t attr;

	/* Initialize mutex and condition variable objects */
  	pthread_mutex_init(&count_mutex, NULL);
  	pthread_cond_init (&count_threshold_cv, NULL);

	//printf("Before starting the threads\n");

	/* For portability, explicitly create threads in a joinable state */
  	pthread_attr_init(&attr);
  	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
  	pthread_create(&threads[0], &attr, handle_session, (void *)t1);
  	pthread_create(&threads[1], &attr, kanon, (void *)t2);

	//printf("After starting the threads\n");
	
	/* Wait for all threads to complete */
  	for (i=0; i<NUM_THREADS; i++) {
		//printf("join %d\n", i);
    		pthread_join(threads[i], NULL);
  	}
  	//printf ("Main(): Waited on %d  threads. Done.\n", NUM_THREADS);

  	/* Clean up and exit */
  	pthread_attr_destroy(&attr);
  	pthread_mutex_destroy(&count_mutex);
  	pthread_cond_destroy(&count_threshold_cv);
  	pthread_exit(NULL);

	return 0;
}
