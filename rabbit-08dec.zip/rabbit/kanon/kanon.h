/***************************************************************************
 * CONTAINS DEFINITIONS/CONSTANTS
 ****************************************************************************/

#ifndef _LDIV_H
#define _LDIV_H

# include <list>
# include <set>
# include <vector>


# define CENTERS 1024
//for iDist cluster centers

//TODO: CHANGE
# define DIM 7


extern int K;
extern int N;//dataset size

using namespace std;

typedef struct DATA
{
	double tmp_sort_value;
	double data[DIM];
	int id;
} DATA;

typedef struct IntervalEntry{
	int start;
	int finish;
	int count;
} IntervalEntry;

/*used for attribute hierarchy*/
typedef struct Hentry{
	int max_level;
	set <int> unique;
	vector <IntervalEntry> levels[3];
}Hentry;

extern unsigned long int domain_length[];
extern unsigned long int domain_finish[];
extern unsigned long int domain_start[];

void hbt_sort_array(DATA **objs, int count, bool normalized);
int sort_hilbert(const void *d1, const void *d2);
void determine_order(DATA **Data,int N,DATA **Sample,int SAMPLE_SIZE);
double _2Dist(DATA **Data, int i, int j);

#endif /* _LDIV_H */
